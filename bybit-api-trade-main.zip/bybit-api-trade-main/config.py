api_keys = [
    {
        "api_key": "5YXmlaq8sdnMTNkzbA",
        "api_secret": "VcnO3ZTBPFymS99VjgzadtzPUyjDlbN8Iuqy"
    },
]

# для множества сессий